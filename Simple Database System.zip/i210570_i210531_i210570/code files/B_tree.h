#pragma once
#include <cmath>
#include <iostream>
#include "Util.h"
#include "SLinkedList.h"
using namespace std;



int convertStringToInt(int length, string toBeConverted);

double convertStringToDouble(string toBeConverted);
void moveCurrentFile(char*& filename, int numToSet);

float return_ans(float num)
{
	return ceil(num);
}

template <typename T>
class BTreeNode
{
public:


	T* keys; // array of keys of each node
	int min_degree; // lower bound of the number of childeren
	BTreeNode** c_pointers;
	int num_keys; // cureent number of keys in the BtreeNode
	bool isLeaf; //if the particular node is a leaf or not

	string* nodeFileName; // stores the filename in which node is stored
	SLinkedList<string>* file; //store files of duplicates
	SLinkedList<int>* line;  // stores lines of dupliactes

	BTreeNode()
	{




	}
	BTreeNode(int min_deg, bool Leaf)
	{
		min_degree = min_deg;
		isLeaf = Leaf;

		keys = new T[2 * min_degree - 1]; //order -1
		c_pointers = new BTreeNode * [2 * min_degree];
		num_keys = 0;
		nodeFileName = new string[2 * min_degree - 1];
		file = new SLinkedList<string>[2 * min_degree - 1];
		line = new SLinkedList<int>[2 * min_degree - 1];
	}

	void print_btree() {

		int i;
		for (i = 0; i < num_keys; i++)
		{
			if (!isLeaf)
			{
				c_pointers[i]->print_btree();
			}
			cout << keys[i] << "  \n";
			/*line[i].print();
			cout << endl;*/


		}

		if (!isLeaf)
		{
			c_pointers[i]->print_btree();
		}

	}

	BTreeNode* search_item(T num)
	{
		//initialising iterator
		int i = 0;


		//traversing through the keys to check if the key is found
		//that particular node

		while (num > keys[i] && i < num_keys)
		{
			i++;
		}

		if (keys[i] == num)
		{
			return this;

		}

		//meaning nt found on this node
		if (isLeaf)
		{
			return NULL;
		}
		// goes to its child pointers to checks
		return c_pointers[i]->search_item(num);
	}

	void split_tree(int ind, BTreeNode* break_point)
	{

		BTreeNode* temp = new BTreeNode(break_point->min_degree, break_point->isLeaf);

		temp->num_keys = min_degree - 1;

		// copy some keYS

		for (int i = 0; i < min_degree - 1; i++)
		{
			temp->keys[i] = break_point->keys[i + min_degree];
			temp->nodeFileName[i] = break_point->nodeFileName[i + min_degree];
			temp->line[i] = break_point->line[i + min_degree];
			temp->file[i] = break_point->file[i + min_degree];

		}

		if (!break_point->isLeaf)
		{
			for (int i = 0; i < min_degree; i++)
			{
				temp->c_pointers[i] = break_point->c_pointers[i + min_degree];
			}

		}

		//numofkey in breakpoint chagnes 
		break_point->num_keys = min_degree - 1;

		//create space
		for (int j = num_keys; j >= ind + 1; j--)
		{
			c_pointers[j + 1] = c_pointers[j];
		}


		c_pointers[ind + 1] = temp;

		//making way for keys aswell
		for (int j = num_keys - 1; j >= ind; j--)
		{
			keys[j + 1] = keys[j];
			nodeFileName[j + 1] = nodeFileName[j];
			line[j + 1] = line[j];
			file[j + 1] = file[j];

		}

		keys[ind] = break_point->keys[min_degree - 1];
		nodeFileName[ind] = break_point->nodeFileName[min_degree - 1];
		line[ind] = break_point->line[min_degree - 1];
		file[ind] = break_point->file[min_degree - 1];




		num_keys++;
	}

	void insert_if_not_full(T num, string file_name, int line_no)
	{
		int ind = num_keys - 1;

		if (isLeaf)
		{

			//where to insert this key
			while (keys[ind] > num && ind >= 0)
			{


				ind--;
			}

			if (keys[ind] == num)
			{
				file[ind].insert(file_name);
				line[ind].insert(line_no);
				return;
			}

			ind = num_keys - 1;
			while (keys[ind] > num && ind >= 0)
			{

				keys[ind + 1] = keys[ind];
				nodeFileName[ind + 1] = nodeFileName[ind];
				line[ind + 1] = line[ind];
				file[ind + 1] = file[ind];


				ind--;
			}


			keys[ind + 1] = num;
			nodeFileName[ind + 1] = file_name;
			line[ind + 1].insert(line_no);
			file[ind + 1].insert(file_name);


			num_keys++;
		}
		else  // internal node 
		{
			//t get index
			while (ind >= 0 && keys[ind] > num)
			{

				ind--;

			}

			if (keys[ind] == num)
			{
				file[ind].insert(file_name);
				line[ind].insert(line_no);
				return;
			}
			if (c_pointers[ind + 1]->num_keys == 2 * min_degree - 1)
			{
				split_tree(ind + 1, c_pointers[ind + 1]);

				if (keys[ind + 1] < num)
				{
					ind++;
				}

			}
			c_pointers[ind + 1]->insert_if_not_full(num, file_name, line_no);
		}
	}

};

template <typename T>
class BTree {

public:

	BTreeNode<T>* root;
	int min_degree_tree;

	BTree(int min_degree_tree)
	{
		root = NULL;
		this->min_degree_tree = min_degree_tree;
	}
	void print_tree()
	{
		if (root)
		{
			root->print_btree();
		}
		return;
	}
	BTreeNode<T>* search(T num)
	{
		if (root)
		{
			return	root->search_item(num);
		}
		return NULL;
	}

	void insert(T num, string filename, int line_no)
	{
		if (!root) // foorst element in the tree
		{
			root = new BTreeNode<T>(min_degree_tree, true);
			root->keys[0] = num;
			root->num_keys = 1;
			root->nodeFileName[0] = filename;
			root->line[0].insert(line_no);
			root->file[0].insert(filename);
		}
		else // ther elements already present in the tree 
		{
			if (root->num_keys == 2 * min_degree_tree - 1)
			{
				BTreeNode<T>* temp = new BTreeNode<T>(min_degree_tree, false);

				temp->c_pointers[0] = root; // new root made

				temp->split_tree(0, root);

				int i = 0;
				if (temp->keys[0] < num)
				{
					i++;
				}
				temp->c_pointers[i]->insert_if_not_full(num, filename, line_no);

				root = temp;

			}
			else //if node not full
			{
				root->insert_if_not_full(num, filename, line_no);
			}

		}



	}


};


template <typename T>
void create_btree_from_data(int dataField)
{

	BTree<T> indexTree(5);

	// ------ declaring variables for filenames

	int fileNum = 1;

	char* filename = new char[200];

	//char currentFile[] = "C:/Users/Haris'/source/repos/haris-sohail/DS-Project/datafiles/NCHS_-_Leading_Causes_of_Death__United_States_1.csv\0";

	for (int i = 0; i < 1; i++, fileNum++) // make index tree on all the files
	{
		moveCurrentFile(filename, fileNum);

		//strcpy(filename, "../datafiles/sample1.csv");

		// ------ opening the file

		ifstream fileIn;
		ofstream fileOut;

		int keyForTree, line = 1;

		string key;
		int intKey;
		double doubleKey;
		bool tempFlag = 0;

		char temp;

		fileIn.open(filename);

		if (fileIn)
		{
			while (fileIn.eof() == false) // read the file till the end of file
			{
				fileIn.get(temp);

				if (tempFlag == 1)
				{
					temp = '\n';
				}

				if (temp == '\n') // in case we find a new line, the ID is stored right after it
				{
					line++;

					if (dataField == 1) // ID
					{
						getline(fileIn, key, ','); // read until the first comma
					}

					else if (dataField == 2) // Year
					{
						// read until the 2nd comma

						getline(fileIn, key, ',');
						getline(fileIn, key, ',');
					}
					else if (dataField == 6) // Deaths
					{
						// read until the 6th comma

						getline(fileIn, key, ',');
						getline(fileIn, key, ',');
						getline(fileIn, key, ',');
						getline(fileIn, key, ',');
						getline(fileIn, key, ',');
						getline(fileIn, key, ',');
					}

					else if (dataField == 7) // Age Adjusted Death Rate
					{
						// read until the 7th comma

						getline(fileIn, key, ',');
						getline(fileIn, key, ',');
						getline(fileIn, key, ',');
						getline(fileIn, key, ',');
						getline(fileIn, key, ',');
						getline(fileIn, key, ',');
						getline(fileIn, key, '\n');

						tempFlag = 1;

					}

					if (fileIn.eof() == true)
					{
						break;
					}

					if (dataField != 7) // key is an integer
					{
						intKey = convertStringToInt(key.length(), key); // convert the character value of ID to int

						indexTree.insert(intKey, filename, line); // insert the index in the tree
					}
					else // key is a double
					{
						doubleKey = convertStringToDouble(key);

						indexTree.insert(doubleKey, filename, line); // insert the index in the tree
					}
				}
			}
		}
		else
		{
			cout << "Error opening file" << endl;
		}

		indexTree.print_tree();
	}



}

void createBtrees(int indexChoice)
{
	if ((indexChoice == 1) || (indexChoice == 2) || (indexChoice == 6)) // these are all the int key choices
	{
		create_btree_from_data<int>(indexChoice);
	}
	else if ((indexChoice == 7)) // this is the floating point key choice
	{
		create_btree_from_data<double>(indexChoice);
	}

	//else if ((indexChoice >= 3) && (indexChoice <= 5)) // these are all string key choices
	//{
	//	createAVLonStringKey(indexChoice);
	//}
}