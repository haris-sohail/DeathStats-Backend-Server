#pragma once

#include <iostream>
#include <queue>
using namespace std;

enum COLOR { RED, BLACK };

class Node
{
public:
    int val;
    COLOR color;
    Node* left, * right, * parent;

    Node(int val) : val(val)
    {
        parent = left = right = NULL;
        color = RED;
    }

    Node* uncle()
    {
        // if the node doesn't have a parent or a grandparent, then uncle cannot exist
        if (!parent || !parent->parent)
            return NULL;
        if (parent->isleftchild())
            // if the uncle is present on the left
            return parent->parent->right;
        else
            // if the uncle is present on the right
            return parent->parent->left;
    }

    // check if node is left child of parent
    bool isleftchild()
    {
        return this == parent->left;
    }

    Node* sibling()
    {
        // if parent doesn't exist
        if (!parent)
            return NULL;
        if (isleftchild())
            return parent->right;
        return parent->left;
    }

    //moves node down and moves given node in its place
    void movenodedown(Node* n)
    {
        if (parent != NULL)
        {
            if (isleftchild())
                parent->left = n;
            else
                parent->right = n;
        }
        n->parent = parent;
        parent = n;
    }

    bool hasredchild()
    {
        return (left != NULL && left->color == RED) || (right != NULL && right->color == RED);
    }
};

class RBTree
{
    Node* root;

    // left rotates the given node
    void leftRotate(Node* n)
    {
        // the node's right child will be the new parent
        Node* temp = n->right;
        if (n == root)
            root = temp;
        n->movenodedown(temp);
        n->right = temp->left;
        if (temp->left != NULL)
            temp->left->parent = n;
        temp->left = n;
    }

    void rightRotate(Node* n)
    {
        // the node's left child will be the new parent
        Node* temp = n->left;
        if (n == root)
            root = temp;
        n->movenodedown(temp);
        n->left = temp->right;
        if (temp->right != NULL)
            temp->right->parent = n;
        temp->right = n;
    }

    void colorswap(Node* n1, Node* n2)
    {
        COLOR temp;
        temp = n1->color;
        n1->color = n2->color;
        n2->color = temp;
    }

    void swapValues(Node* val1, Node* val2)
    {
        int temp;
        temp = val1->val;
        val1->val = val2->val;
        val2->val = temp;
    }

    // fix red red at given node
    void fixRedrepetition(Node* n)
    {
        // if x is root, color it black and return
        if (n == root)
        {
            n->color = BLACK;
            return;
        }

        // initialize parent, grandparent, uncle
        Node* parent = n->parent;
        Node* grandparent = parent->parent;
        Node* uncle = n->uncle();

        if (parent->color != BLACK)
        {
            if (uncle != NULL && uncle->color == RED)
            {
                // if the uncle is red, perform recoloring and recurse
                parent->color = BLACK;
                uncle->color = BLACK;
                grandparent->color = RED;
                fixRedrepetition(grandparent);
            }
            else
            {
                // to perform the rotations (LL, LR, RL, RR)
                if (parent->isleftchild())
                {
                    if (n->isleftchild())
                        colorswap(parent, grandparent);
                    else
                    {
                        leftRotate(parent);
                        colorswap(n, grandparent);
                    }
                    rightRotate(grandparent);
                }
                else
                {
                    if (n->isleftchild())
                    {
                        rightRotate(parent);
                        colorswap(n, grandparent);
                    }
                    else
                        colorswap(parent, grandparent);
                    leftRotate(grandparent);
                }
            }
        }
    }

    Node* successor(Node* n)
    {
        Node* temp = n;

        while (temp->left)
            temp = temp->left;
        return temp;
    }

    Node* BSTreplace(Node* x)
    {
        // if node has 2 children
        if (x->left && x->right)
            return successor(x->right);
        // if node has 1 child
        if (x->left != NULL)
            return x->left;
        else
            return x->right;
        // if node is a leaf node
        if (!x->left && !x->right)
            return NULL;
    }

    // deletes a given node
    void deleteNode(Node* n)
    {
        Node* u = BSTreplace(n);

        // True when both nodes black
        bool u_n_black = ((!u || u->color == BLACK) && (n->color == BLACK));
        Node* parent = n->parent;

        if (!u)
        {
            // u is NULL so n is leaf
            if (n == root)
                // n is root, making root null
                root = NULL;
            else
            {
                if (u_n_black)  //if both nodes are black
                    // n is leaf, fix double black at n
                    fixblackrepetition(n);
                else
                {
                    // either of the nodes is red
                    if (n->sibling())
                        // if sibling is not null, make the node red
                        n->sibling()->color = RED;
                }

                // delete n from the tree
                if (n->isleftchild())
                    parent->left = NULL;
                else
                    parent->right = NULL;
            }
            delete n;
            return;
        }

        if (!n->left || !n->right)
        {
            // if node has only 1 child
            if (n == root)
            {
                // if n is root, update the value of  n and delete u
                n->val = u->val;
                n->left = n->right = NULL;
                delete u;
            }
            else
            {
                // remove n from tree and move u up
                if (n->isleftchild())
                    parent->left = u;
                else
                    parent->right = u;
                delete n;
                u->parent = parent;
                if (u_n_black)
                    // if both nodes are black, fix the repetition
                    fixblackrepetition(u);
                else
                    // if either one is red, then color u black
                    u->color = BLACK;
            }
            return;
        }

        // if n has 2 children, swap values with successor and recurse
        swapValues(u, n);
        deleteNode(u);
    }

    void fixblackrepetition(Node* n)
    {
        if (n == root)
            return;

        Node* sibling = n->sibling(), * parent = n->parent;
        if (!sibling)
            // if both nodes are black
            fixblackrepetition(parent);
        else
        {
            if (sibling->color == RED)
            {
                parent->color = RED;
                sibling->color = BLACK;
                if (sibling->isleftchild())
                    // left case
                    rightRotate(parent);
                else
                    // right case
                    leftRotate(parent);
                fixblackrepetition(n);
            }
            else
            {
                // Sibling black
                if (sibling->hasredchild())
                {
                    // the node has one red child
                    if (sibling->left && sibling->left->color == RED)
                    {
                        if (sibling->isleftchild())
                        {
                            // left left
                            sibling->left->color = sibling->color;
                            sibling->color = parent->color;
                            rightRotate(parent);
                        }
                        else
                        {
                            // right left
                            sibling->left->color = parent->color;
                            rightRotate(sibling);
                            leftRotate(parent);
                        }
                    }
                    else
                    {
                        if (sibling->isleftchild())
                        {
                            // left right
                            sibling->right->color = parent->color;
                            leftRotate(sibling);
                            rightRotate(parent);
                        }
                        else
                        {
                            // right right
                            sibling->right->color = sibling->color;
                            sibling->color = parent->color;
                            leftRotate(parent);
                        }
                    }
                    parent->color = BLACK;
                }
                else
                {
                    // if the node has 2 black children
                    sibling->color = RED;
                    if (parent->color == BLACK)
                        fixblackrepetition(parent);
                    else
                        parent->color = BLACK;
                }
            }
        }
    }

    // prints the tree inorder 
    void inorder(Node* n)
    {
        if (n == NULL)
            return;
        inorder(n->left);
        cout << n->val << " ";
        inorder(n->right);
    }

public:
    RBTree()
    {
        root = NULL;
    }

    Node* getRoot()
    {
        return root;
    }

    Node* search(int n) // is used for deletion 
    {
        Node* temp = root;
        while (temp != NULL)
        {
            if (n < temp->val)
            {
                if (!temp->left)
                    break;
                else
                    temp = temp->left;
            }
            else if (n > temp->val)
            {
                if (!temp->right)
                    break;
                else
                    temp = temp->right;
            }
            else
                break;
        }
        return temp;
    }

    // inserts new value in the tree
    void insert(int n)
    {
        Node* newNode = new Node(n);
        if (!root)
        {
            // if tree is empty, insert the value as root
            newNode->color = BLACK;
            root = newNode;
        }
        else
        {
            Node* temp = search(n);
            if (temp->val == n)
                return;

            newNode->parent = temp;

            if (n < temp->val)
                temp->left = newNode;
            else
                temp->right = newNode;

            // fix red red voilaton if exists
            fixRedrepetition(newNode);
        }
    }

    // function to delete the node using the value given by the user
    void deleteByVal(int n)
    {
        if (!root)
            return;

        Node* v = search(n), * u;

        if (v->val != n)
        {
            cout << "Node of given value " << n << " does not exist" << endl;
            return;
        }

        deleteNode(v);
    }

    // prints inorder of the tree by calling the inorder function
    void printInOrder()
    {
        cout << "Inorder: " << endl;
        if (root == NULL)
            cout << "Tree is empty" << endl;
        else
            inorder(root);
        cout << endl;
    }
};
